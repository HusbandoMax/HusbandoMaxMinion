local tbl = 
{
	Enabled = true,
	Name = "[HM] - Halatali",
	Notes = "Release",
	Time = 1759657929,
	Version = 5,
}



return tbl