local tbl = 
{
	Enabled = true,
	Name = "[HM] - Halatali",
	Notes = "Release",
	Time = 1732216103,
	Version = 3,
}



return tbl