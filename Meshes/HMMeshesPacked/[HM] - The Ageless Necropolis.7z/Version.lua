local tbl = 
{
	Enabled = true,
	Name = "[HM] - The Ageless Necropolis",
	Notes = "Release",
	Time = 1754745068,
	Version = 3,
}



return tbl