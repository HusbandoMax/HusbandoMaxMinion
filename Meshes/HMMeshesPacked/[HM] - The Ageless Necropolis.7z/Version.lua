local tbl = 
{
	Enabled = true,
	Name = "[HM] - The Ageless Necropolis",
	Notes = "Release",
	Time = 1754538898,
	Version = 2,
}



return tbl