local tbl = 
{
	Name = "[HM] - The Heroes' Gauntlet",
	Notes = "Release",
	Time = 1672237975,
	Version = 3,
}



return tbl