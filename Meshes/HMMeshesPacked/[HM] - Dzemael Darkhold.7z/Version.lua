local tbl = 
{
	Enabled = true,
	Name = "[HM] - Dzemael Darkhold",
	Notes = "Release",
	Time = 1766069568,
	Version = 2,
}



return tbl