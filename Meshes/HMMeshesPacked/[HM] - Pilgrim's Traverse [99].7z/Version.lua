local tbl = 
{
	Enabled = true,
	Name = "[HM] - Pilgrim's Traverse [99]",
	Notes = "Release",
	Time = 1762424621,
	Version = 4,
}



return tbl