local tbl = 
{
	Enabled = true,
	Name = "[HM] - Pilgrim's Traverse [99]",
	Notes = "Release",
	Time = 1762081051,
	Version = 3,
}



return tbl