local tbl = 
{
	Enabled = true,
	Name = "[HM] - Tuliyollal",
	Notes = "Release",
	Time = 1742721702,
	Version = 3,
}



return tbl