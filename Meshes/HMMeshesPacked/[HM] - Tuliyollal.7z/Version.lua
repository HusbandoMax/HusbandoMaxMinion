local tbl = 
{
	Enabled = false,
	Name = "[HM] - Tuliyollal",
	Notes = "Release",
	Time = 1722690995,
	Version = 2,
}



return tbl