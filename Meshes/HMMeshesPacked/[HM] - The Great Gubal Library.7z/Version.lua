local tbl = 
{
	Name = "[HM] - The Great Gubal Library",
	Notes = "Release",
	Time = 1673838894,
	Version = 3,
}



return tbl