local tbl = 
{
	Name = "[HM] - Paglth'an",
	Notes = "Release",
	Time = 1672237979,
	Version = 3,
}



return tbl