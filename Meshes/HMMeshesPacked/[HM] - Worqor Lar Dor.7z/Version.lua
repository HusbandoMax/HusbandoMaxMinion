local tbl = 
{
	Enabled = true,
	Name = "[HM] - Worqor Lar Dor",
	Notes = "Release",
	Time = 1721254381,
	Version = 2,
}



return tbl