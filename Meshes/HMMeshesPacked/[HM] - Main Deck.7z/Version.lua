local tbl = 
{
	Enabled = true,
	Name = "[HM] - Main Deck",
	Notes = "Release",
	Time = 1753325745,
	Version = 2,
}



return tbl