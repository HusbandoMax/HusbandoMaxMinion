local tbl = 
{
	Enabled = true,
	Name = "[HM][Q] - The Warmth of Family",
	Notes = "Release",
	Time = 1738191761,
	Version = 2,
}



return tbl