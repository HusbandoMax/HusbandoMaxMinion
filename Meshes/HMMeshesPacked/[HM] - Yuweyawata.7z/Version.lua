local tbl = 
{
	Enabled = true,
	Name = "[HM] - Yuweyawata",
	Notes = "Release",
	Time = 1731794387,
	Version = 2,
}



return tbl