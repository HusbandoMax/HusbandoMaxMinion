local tbl = 
{
	Enabled = true,
	Name = "[HM] - Yuweyawata",
	Notes = "Release",
	Time = 1731834407,
	Version = 3,
}



return tbl