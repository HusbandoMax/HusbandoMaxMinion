local tbl = 
{
	Name = "[HM] - Haukke Manor v2",
	Notes = "Release",
	Time = 1672238026,
	Version = 3,
}



return tbl