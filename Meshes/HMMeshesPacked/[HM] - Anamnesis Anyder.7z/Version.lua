local tbl = 
{
	Name = "[HM] - Anamnesis Anyder",
	Notes = "Release",
	Time = 1672237972,
	Version = 3,
}



return tbl