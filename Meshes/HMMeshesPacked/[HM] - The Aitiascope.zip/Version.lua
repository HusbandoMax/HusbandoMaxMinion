local tbl = 
{
	Name = "[HM] - The Aitiascope",
	Notes = "Release",
	Time = 1672208723,
	Version = 2,
}



return tbl