local tbl = 
{
	Enabled = true,
	Name = "[HM] - North Shroud",
	Notes = "Release",
	Time = 1741066856,
	Version = 4,
}



return tbl