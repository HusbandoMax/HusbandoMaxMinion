local tbl = 
{
	Enabled = true,
	Name = "[HM] - North Shroud",
	Notes = "Release",
	Time = 1739349987,
	Version = 2,
}



return tbl