local tbl = 
{
	Enabled = true,
	Name = "[HM] - North Shroud",
	Notes = "Release",
	Time = 1740264610,
	Version = 3,
}



return tbl