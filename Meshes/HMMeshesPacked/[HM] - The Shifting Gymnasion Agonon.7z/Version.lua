local tbl = 
{
	Name = "[HM] - The Shifting Gymnasion Agonon",
	Notes = "Release",
	Time = 1673703183,
	Version = 2,
}



return tbl