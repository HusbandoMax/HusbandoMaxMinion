local tbl = 
{
	Enabled = true,
	Name = "[HM] - The Gold Saucer",
	Notes = "Tweaks",
	Time = 1736818613,
	Version = 3,
}



return tbl