local tbl = 
{
	Name = "[HM] - Copperbell Mines v2",
	Notes = "Release",
	Time = 1672238007,
	Version = 3,
}



return tbl