local tbl = 
{
	Enabled = false,
	Name = "[HM] - The Excitatron 6000",
	Notes = "Release",
	Time = 1736477618,
	Version = 2,
}



return tbl