local tbl = 
{
	Name = "[HM] - The Wanderer's Palace (Hard)",
	Notes = "Release",
	Time = 1672208730,
	Version = 2,
}



return tbl