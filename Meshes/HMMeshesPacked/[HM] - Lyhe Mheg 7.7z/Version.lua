local tbl = 
{
	Enabled = true,
	Name = "[HM] - Lyhe Mheg 7",
	Notes = "Release",
	Time = 1739748343,
	Version = 2,
}



return tbl