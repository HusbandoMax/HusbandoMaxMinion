local tbl = 
{
	Name = "[HM] - G-Savior Deck",
	Notes = "Release",
	Time = 1690639655,
	Version = 2,
}



return tbl