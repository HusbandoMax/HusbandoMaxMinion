local tbl = 
{
	Enabled = true,
	Name = "[HM] - Solution Nine",
	Notes = "Mesh Tweak",
	Time = 1729886938,
	Version = 3,
}



return tbl