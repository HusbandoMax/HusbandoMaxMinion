local tbl = 
{
	Name = "[HM] - The Thousand Maws of Toto-Rak v2",
	Notes = "Release",
	Time = 1672208804,
	Version = 2,
}



return tbl