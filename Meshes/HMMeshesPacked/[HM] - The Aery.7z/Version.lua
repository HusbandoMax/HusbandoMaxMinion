local tbl = 
{
	Enabled = true,
	Name = "[HM] - The Aery",
	Notes = "Release",
	Time = 1729897127,
	Version = 2,
}



return tbl