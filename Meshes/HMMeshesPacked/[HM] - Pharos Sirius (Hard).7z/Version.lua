local tbl = 
{
	Name = "[HM] - Pharos Sirius (Hard)",
	Notes = "Release",
	Time = 1672237942,
	Version = 3,
}



return tbl