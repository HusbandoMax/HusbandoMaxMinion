local tbl = 
{
	Name = "[HM] - Alzadaal's Legacy",
	Notes = "Release",
	Time = 1672238042,
	Version = 3,
}



return tbl