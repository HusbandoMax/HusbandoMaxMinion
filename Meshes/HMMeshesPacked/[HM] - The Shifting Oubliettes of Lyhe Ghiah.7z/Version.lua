local tbl = 
{
	Enabled = false,
	Name = "[HM] - The Shifting Oubliettes of Lyhe Ghiah",
	Notes = "Release",
	Time = 1736477616,
	Version = 2,
}



return tbl