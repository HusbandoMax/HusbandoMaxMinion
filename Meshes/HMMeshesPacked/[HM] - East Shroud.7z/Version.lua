local tbl = 
{
	Enabled = true,
	Name = "[HM] - East Shroud",
	Notes = "Release",
	Time = 1739596008,
	Version = 2,
}



return tbl