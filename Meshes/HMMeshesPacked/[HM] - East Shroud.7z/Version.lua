local tbl = 
{
	Enabled = true,
	Name = "[HM] - East Shroud",
	Notes = "Release",
	Time = 1741066851,
	Version = 5,
}



return tbl