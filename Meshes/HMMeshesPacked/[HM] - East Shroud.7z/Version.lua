local tbl = 
{
	Enabled = true,
	Name = "[HM] - East Shroud",
	Notes = "Release",
	Time = 1740264608,
	Version = 4,
}



return tbl