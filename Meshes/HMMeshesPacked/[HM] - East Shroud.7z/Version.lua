local tbl = 
{
	Enabled = true,
	Name = "[HM] - East Shroud",
	Notes = "Release",
	Time = 1740030217,
	Version = 3,
}



return tbl