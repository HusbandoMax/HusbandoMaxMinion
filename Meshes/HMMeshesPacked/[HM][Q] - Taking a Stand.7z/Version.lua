local tbl = 
{
	Enabled = true,
	Name = "[HM][Q] - Taking a Stand",
	Notes = "Release",
	Time = 1721307627,
	Version = 2,
}



return tbl