local tbl = 
{
	Name = "[HM] - Baelsar's Wall",
	Notes = "Release",
	Time = 1674097817,
	Version = 2,
}



return tbl