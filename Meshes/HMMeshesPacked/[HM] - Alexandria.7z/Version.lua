local tbl = 
{
	Enabled = true,
	Name = "[HM] - Alexandria",
	Notes = "Release",
	Time = 1720681346,
	Version = 2,
}



return tbl