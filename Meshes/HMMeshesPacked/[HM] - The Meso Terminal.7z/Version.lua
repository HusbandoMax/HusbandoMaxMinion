local tbl = 
{
	Enabled = true,
	Name = "[HM] - The Meso Terminal",
	Notes = "Release",
	Time = 1754497540,
	Version = 2,
}



return tbl