local tbl = 
{
	Enabled = true,
	Name = "[HM] - Origenics",
	Notes = "Release",
	Time = 1720400950,
	Version = 2,
}



return tbl