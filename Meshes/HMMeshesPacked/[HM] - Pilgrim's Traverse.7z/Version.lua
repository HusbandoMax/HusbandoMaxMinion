local tbl = 
{
	Enabled = true,
	Name = "[HM] - Pilgrim's Traverse",
	Notes = "Release",
	Time = 1761266164,
	Version = 3,
}



return tbl