local tbl = 
{
	Enabled = true,
	Name = "[HM] - Pilgrim's Traverse",
	Notes = "Release",
	Time = 1761722927,
	Version = 5,
}



return tbl