local tbl = 
{
	Enabled = false,
	Name = "[HM] - Pilgrim's Traverse",
	Notes = "Release",
	Time = 1761209158,
	Version = 2,
}



return tbl