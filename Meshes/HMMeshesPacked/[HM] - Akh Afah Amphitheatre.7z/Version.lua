local tbl = 
{
	Enabled = true,
	Name = "[HM] - Akh Afah Amphitheatre",
	Notes = "Release",
	Time = 1759578298,
	Version = 2,
}



return tbl