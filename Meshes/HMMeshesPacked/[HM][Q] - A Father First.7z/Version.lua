local tbl = 
{
	Enabled = true,
	Name = "[HM][Q] - A Father First",
	Notes = "Release",
	Time = 1721469221,
	Version = 2,
}



return tbl