local tbl = 
{
	Enabled = true,
	Name = "[HM][Q] - A Father First",
	Notes = "Release",
	Time = 1721491097,
	Version = 3,
}



return tbl