local tbl = 
{
	Enabled = true,
	Name = "[HM] - Central Shroud",
	Notes = "Release",
	Time = 1738542697,
	Version = 2,
}



return tbl