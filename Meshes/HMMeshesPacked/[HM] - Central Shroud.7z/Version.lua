local tbl = 
{
	Enabled = true,
	Name = "[HM] - Central Shroud",
	Notes = "Release",
	Time = 1740264612,
	Version = 3,
}



return tbl