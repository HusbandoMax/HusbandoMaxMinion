local tbl = 
{
	Name = "[HM] - The Thousand Maws of Toto-Rak v2",
	Notes = "Release",
	Time = 1672238023,
	Version = 3,
}



return tbl