local tbl = 
{
	Enabled = true,
	Name = "[HM] - Summit of Everkeep",
	Notes = "Release",
	Time = 1721491218,
	Version = 2,
}



return tbl