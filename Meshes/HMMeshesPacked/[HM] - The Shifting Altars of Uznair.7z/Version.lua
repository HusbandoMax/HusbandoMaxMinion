local tbl = 
{
	Enabled = true,
	Name = "[HM] - The Shifting Altars of Uznair",
	Notes = "Release",
	Time = 1735594893,
	Version = 2,
}



return tbl