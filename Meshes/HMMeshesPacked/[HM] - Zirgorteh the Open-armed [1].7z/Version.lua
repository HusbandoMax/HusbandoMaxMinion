local tbl = 
{
	Enabled = true,
	Name = "[HM] - Zirgorteh the Open-armed [1]",
	Notes = "Release",
	Time = 1759900340,
	Version = 2,
}



return tbl