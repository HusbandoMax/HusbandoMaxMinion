local tbl = 
{
	Enabled = true,
	Name = "[HM] - Zirgorteh the Open-armed [1]",
	Notes = "Release",
	Time = 1760133439,
	Version = 3,
}



return tbl