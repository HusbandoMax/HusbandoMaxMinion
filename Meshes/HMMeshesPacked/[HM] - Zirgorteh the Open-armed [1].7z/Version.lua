local tbl = 
{
	Enabled = true,
	Name = "[HM] - Zirgorteh the Open-armed [1]",
	Notes = "Release",
	Time = 1761343351,
	Version = 7,
}



return tbl