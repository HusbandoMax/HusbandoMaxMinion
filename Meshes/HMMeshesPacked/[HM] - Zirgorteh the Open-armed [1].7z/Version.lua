local tbl = 
{
	Enabled = true,
	Name = "[HM] - Zirgorteh the Open-armed [1]",
	Notes = "Release",
	Time = 1760519509,
	Version = 5,
}



return tbl