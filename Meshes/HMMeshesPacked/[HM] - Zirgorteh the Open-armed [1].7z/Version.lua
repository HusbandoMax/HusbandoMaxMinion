local tbl = 
{
	Enabled = true,
	Name = "[HM] - Zirgorteh the Open-armed [1]",
	Notes = "Release",
	Time = 1760831429,
	Version = 6,
}



return tbl