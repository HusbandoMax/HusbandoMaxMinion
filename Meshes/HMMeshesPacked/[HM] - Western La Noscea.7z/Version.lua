local tbl = 
{
	Enabled = true,
	Name = "[HM] - Western La Noscea",
	Notes = "Release",
	Time = 1739997928,
	Version = 2,
}



return tbl