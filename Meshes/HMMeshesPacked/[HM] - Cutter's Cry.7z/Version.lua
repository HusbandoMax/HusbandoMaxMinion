local tbl = 
{
	Enabled = true,
	Name = "[HM] - Cutter's Cry",
	Notes = "Release",
	Time = 1759484616,
	Version = 4,
}



return tbl