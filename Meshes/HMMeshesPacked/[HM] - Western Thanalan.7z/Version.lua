local tbl = 
{
	Enabled = true,
	Name = "[HM] - Western Thanalan",
	Notes = "Release",
	Time = 1755256332,
	Version = 2,
}



return tbl