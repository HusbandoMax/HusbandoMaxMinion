local tbl = 
{
	Name = "[HM] - Copperbell Mines v2",
	Notes = "Release",
	Time = 1672208679,
	Version = 2,
}



return tbl