local tbl = 
{
	Enabled = true,
	Name = "[HM] - Lyhe Mheg Rank 6 Solo Duty",
	Notes = "Release",
	Time = 1740956485,
	Version = 2,
}



return tbl