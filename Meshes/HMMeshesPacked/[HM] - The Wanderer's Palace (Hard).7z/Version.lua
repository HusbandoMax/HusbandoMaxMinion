local tbl = 
{
	Name = "[HM] - The Wanderer's Palace (Hard)",
	Notes = "Release",
	Time = 1672237937,
	Version = 3,
}



return tbl