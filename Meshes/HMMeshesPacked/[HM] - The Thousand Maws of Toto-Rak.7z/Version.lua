local tbl = 
{
	Name = "[HM] - The Thousand Maws of Toto-Rak",
	Notes = "Release",
	Time = 1672237930,
	Version = 3,
}



return tbl