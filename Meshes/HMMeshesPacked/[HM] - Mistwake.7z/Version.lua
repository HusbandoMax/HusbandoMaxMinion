local tbl = 
{
	Enabled = false,
	Name = "[HM] - Mistwake",
	Notes = "Release",
	Time = 1766069565,
	Version = 2,
}



return tbl