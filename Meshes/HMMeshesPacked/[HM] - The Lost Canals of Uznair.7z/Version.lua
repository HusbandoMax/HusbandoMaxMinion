local tbl = 
{
	Enabled = false,
	Name = "[HM] - The Lost Canals of Uznair",
	Notes = "Release",
	Time = 1736477622,
	Version = 2,
}



return tbl