local tbl = 
{
	Enabled = true,
	Name = "[HM] - Ihuykatumu",
	Notes = "OMC Tweak",
	Time = 1721497206,
	Version = 3,
}



return tbl