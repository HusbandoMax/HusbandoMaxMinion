local tbl = 
{
	Enabled = true,
	Name = "[HM] - The Wanderer's Palace",
	Notes = "Release",
	Time = 1759791636,
	Version = 2,
}



return tbl