local tbl = 
{
	Enabled = true,
	Name = "[HM][Q] - The Protector and the Destroyer",
	Notes = "Release",
	Time = 1721469154,
	Version = 2,
}



return tbl