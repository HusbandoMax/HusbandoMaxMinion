local tbl = 
{
	Name = "[HM] - The Aitiascope",
	Notes = "Release",
	Time = 1672237994,
	Version = 3,
}



return tbl