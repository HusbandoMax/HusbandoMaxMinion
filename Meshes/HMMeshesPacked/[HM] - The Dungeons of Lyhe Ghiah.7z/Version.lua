local tbl = 
{
	Enabled = false,
	Name = "[HM] - The Dungeons of Lyhe Ghiah",
	Notes = "Release",
	Time = 1736477614,
	Version = 2,
}



return tbl