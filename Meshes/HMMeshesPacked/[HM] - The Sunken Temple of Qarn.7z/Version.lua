local tbl = 
{
	Enabled = true,
	Name = "[HM] - The Sunken Temple of Qarn",
	Notes = "Release",
	Time = 1759737103,
	Version = 2,
}



return tbl