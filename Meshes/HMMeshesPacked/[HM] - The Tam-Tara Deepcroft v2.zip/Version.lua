local tbl = 
{
	Name = "[HM] - The Tam-Tara Deepcroft v2",
	Notes = "Release",
	Time = 1672208806,
	Version = 2,
}



return tbl