local tbl = 
{
	Enabled = true,
	Name = "[HM] - Anata Rank 6 Quest",
	Notes = "Release",
	Time = 1741388804,
	Version = 2,
}



return tbl