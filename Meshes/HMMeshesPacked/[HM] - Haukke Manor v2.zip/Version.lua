local tbl = 
{
	Name = "[HM] - Haukke Manor v2",
	Notes = "Release",
	Time = 1672208797,
	Version = 2,
}



return tbl