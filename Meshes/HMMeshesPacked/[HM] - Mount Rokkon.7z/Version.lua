local tbl = 
{
	Enabled = true,
	Name = "[HM] - Mount Rokkon",
	Notes = "Release",
	Time = 1751337510,
	Version = 7,
}



return tbl