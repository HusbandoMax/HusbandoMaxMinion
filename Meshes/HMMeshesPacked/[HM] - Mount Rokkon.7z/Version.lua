local tbl = 
{
	Name = "[HM] - Mount Rokkon",
	Notes = "Left Path Only",
	Time = 1689933640,
	Version = 2,
}



return tbl