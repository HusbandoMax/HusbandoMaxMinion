local tbl = 
{
	Enabled = true,
	Name = "[HM] - Phantom Village",
	Notes = "Release",
	Time = 1748681629,
	Version = 2,
}



return tbl