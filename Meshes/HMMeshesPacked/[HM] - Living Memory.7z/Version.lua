local tbl = 
{
	Enabled = true,
	Name = "[HM] - Living Memory",
	Notes = "Release",
	Time = 1755160145,
	Version = 8,
}



return tbl