local tbl = 
{
	Enabled = true,
	Name = "[HM] - Living Memory",
	Notes = "Release",
	Time = 1765893118,
	Version = 9,
}



return tbl