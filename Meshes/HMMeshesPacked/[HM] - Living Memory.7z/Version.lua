local tbl = 
{
	Enabled = true,
	Name = "[HM] - Living Memory",
	Notes = "Release",
	Time = 1725756511,
	Version = 6,
}



return tbl