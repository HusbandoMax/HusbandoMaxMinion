local tbl = 
{
	Enabled = true,
	Name = "[HM] - Living Memory",
	Notes = "Release",
	Time = 1754611547,
	Version = 7,
}



return tbl