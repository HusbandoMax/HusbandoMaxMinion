local tbl = 
{
	Enabled = false,
	Name = "[HM] - Living Memory",
	Notes = "Release",
	Time = 1722691015,
	Version = 2,
}



return tbl