local tbl = 
{
	Name = "[HM] - Malikah's Well",
	Notes = "Release",
	Time = 1672208654,
	Version = 2,
}



return tbl