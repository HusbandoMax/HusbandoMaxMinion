local tbl = 
{
	Name = "[HM] - Bardam's Mettle",
	Notes = "Release",
	Time = 1685738587,
	Version = 2,
}



return tbl