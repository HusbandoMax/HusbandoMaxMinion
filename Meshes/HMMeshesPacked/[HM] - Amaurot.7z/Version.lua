local tbl = 
{
	Name = "[HM] - Amaurot",
	Notes = "Release",
	Time = 1672237968,
	Version = 3,
}



return tbl