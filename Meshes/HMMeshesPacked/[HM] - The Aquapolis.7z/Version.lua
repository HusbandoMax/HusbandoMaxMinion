local tbl = 
{
	Enabled = true,
	Name = "[HM] - The Aquapolis",
	Notes = "Fixes",
	Time = 1736491215,
	Version = 3,
}



return tbl