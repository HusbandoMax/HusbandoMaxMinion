local tbl = 
{
	Enabled = false,
	Name = "[HM] - The Aquapolis",
	Notes = "Release",
	Time = 1736477610,
	Version = 2,
}



return tbl