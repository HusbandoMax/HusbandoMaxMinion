local tbl = 
{
	Name = "[HM] - Twin Adder Barracks",
	Notes = "Release",
	Time = 1672208821,
	Version = 2,
}



return tbl