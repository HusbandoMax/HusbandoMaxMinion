local tbl = 
{
	Name = "[HM] - Maelstrom Barracks",
	Notes = "Release",
	Time = 1672208775,
	Version = 2,
}



return tbl