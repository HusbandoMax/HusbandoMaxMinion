local tbl = 
{
	Name = "[HM] - The Thousand Maws of Toto-Rak",
	Notes = "Release",
	Time = 1672208770,
	Version = 2,
}



return tbl