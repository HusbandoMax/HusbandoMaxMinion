local tbl = 
{
	Enabled = true,
	Name = "[HM] - Lower Jeuno",
	Notes = "Release",
	Time = 1736825439,
	Version = 2,
}



return tbl