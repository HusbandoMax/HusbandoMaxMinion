local tbl = 
{
	Name = "[HM] - The Tam-Tara Deepcroft v2",
	Notes = "Release",
	Time = 1672238004,
	Version = 3,
}



return tbl