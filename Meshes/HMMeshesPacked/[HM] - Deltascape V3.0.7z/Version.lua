local tbl = 
{
	Name = "[HM] - Deltascape V3.0",
	Notes = "Deltascape v3: Maze Total Rework",
	Time = 1713346990,
	Version = 3,
}



return tbl