local tbl = 
{
	Name = "[HM] - Shisui of the Violet Tides",
	Notes = "Tweaks",
	Time = 1717890466,
	Version = 4,
}



return tbl