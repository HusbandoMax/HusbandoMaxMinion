local tbl = 
{
	Enabled = true,
	Name = "[HM] - The Underkeep",
	Notes = "Release",
	Time = 1742971743,
	Version = 2,
}



return tbl