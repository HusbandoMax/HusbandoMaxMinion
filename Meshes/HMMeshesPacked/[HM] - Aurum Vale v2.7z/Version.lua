local tbl = 
{
	Enabled = true,
	Name = "[HM] - Aurum Vale v2",
	Notes = "Release",
	Time = 1766047642,
	Version = 2,
}



return tbl