local tbl = 
{
	Name = "[HM] - Castrum Meridianum v2",
	Notes = "Release",
	Time = 1672238033,
	Version = 3,
}



return tbl