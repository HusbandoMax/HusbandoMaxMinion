local tbl = 
{
	Enabled = true,
	Name = "[HM] - Vanguard",
	Notes = "Release",
	Time = 1720400946,
	Version = 2,
}



return tbl