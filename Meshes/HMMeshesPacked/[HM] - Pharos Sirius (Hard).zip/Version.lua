local tbl = 
{
	Name = "[HM] - Pharos Sirius (Hard)",
	Notes = "Release",
	Time = 1672208751,
	Version = 2,
}



return tbl