local tbl = 
{
	Enabled = true,
	Name = "[HM][Q] - The Feat of the Brotherhood",
	Notes = "Release",
	Time = 1721307623,
	Version = 2,
}



return tbl