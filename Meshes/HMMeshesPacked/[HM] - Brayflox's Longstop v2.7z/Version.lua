local tbl = 
{
	Enabled = true,
	Name = "[HM] - Brayflox's Longstop v2",
	Notes = "Mesh Tweaks",
	Time = 1721388885,
	Version = 4,
}



return tbl