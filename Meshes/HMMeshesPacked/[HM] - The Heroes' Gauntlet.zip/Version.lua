local tbl = 
{
	Name = "[HM] - The Heroes' Gauntlet",
	Notes = "Release",
	Time = 1672208809,
	Version = 2,
}



return tbl