local tbl = 
{
	Enabled = true,
	Name = "[HM] - Kojin Rank 6 Quest",
	Notes = "Release",
	Time = 1740956479,
	Version = 2,
}



return tbl