local tbl = 
{
	Enabled = true,
	Name = "[HM] - The Striking Tree",
	Notes = "Release",
	Time = 1759578231,
	Version = 3,
}



return tbl